<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from psikolog-html-preview.dextheme.net/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 08 Oct 2025 04:08:32 GMT -->

<head>

    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Aaravam</title>

        <link rel="icon" type="image/x-icon" href="assets/images/logo/title-icon.png" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap"
            rel="stylesheet">

        <link rel="stylesheet" href="assets/css/main.min.css" />
        <link rel="stylesheet" href="assets/css/custom.html" />
        <link rel="stylesheet" href="assets/vendor/css/ekiticons3b71.css" />
        <link rel="stylesheet" href="assets/vendor/css/animate.min.css" />
        <link rel="stylesheet" href="assets/vendor/css/swiper-bundle.min.css" />
        <link rel="stylesheet" href="assets/vendor/css/lightbox.min.css" />
        <script type="text/javascript" src="assets/vendor/js/bootstrap.js"></script>
        <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link
            href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap"
            rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
            rel="stylesheet">
        <link
            href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap"
            rel="stylesheet">

    </head>
</head>

<body>
    <?php include('header.php'); ?>

    <div class="backdrop" id="drawerBackdrop"></div>
    <main class="bg-white">
        <section class="heading-wrapper">
            <div class="dextheme-container">
                <div class="title-breadcrumb">
                    <h2>Contact Us</h2>
                    <div class="breadcrumb-wrapper">
                        <p><a href="index.php">Home</a> - Contact Us</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="consultation-section dextheme-section-padding bg-white">
            <div class="dextheme-container">
                <div class="dextheme-row">
                    <div class="dextheme-col-lg-6 dextehme-col-12 d-flex flex-column justify-content-center">
                        <div class="contact-info">
                            <div class="heading-section mb-4">
                                <h5 class="heading-subtitle">We're Always Here to Listen</h5>
                                <h1 class="heading-title dextheme-w-70 mb-4">
                                    Your Hearing Journey Begins with Us.
                                </h1>
                                <p>
                                    Discover the sounds that make life beautiful. Whether you need a hearing test,
                                    speech therapy, or hearing aid support — our caring specialists are here to help you
                                    every step of the way.
                                </p>
                            </div>
                            <div class="contact-info-list pt-3">
                                <div class="info-item">
                                    <span class="info-icon">
                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-phone-alt"
                                            viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z">
                                            </path>
                                        </svg>
                                    </span>
                                    <div class="info-text">
                                        <span class="text-secondary">Phone</span>
                                        <p class="text-primary">+91 9633 274 214</p>
                                    </div>
                                </div>
                                <div class="info-item">
                                    <span class="info-icon">
                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-envelope"
                                            viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z">
                                            </path>
                                        </svg>
                                    </span>
                                    <div class="info-text">
                                        <span class="text-secondary">E-mail</span>
                                        <p class="text-primary">info@aaravamshc.com</p>
                                    </div>
                                </div>
                                <div class="info-item">
                                    <span class="info-icon">
                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-map-marker-alt"
                                            viewBox="0 0 384 512" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z">
                                            </path>
                                        </svg>
                                    </span>
                                    <div class="info-text">
                                        <span class="text-secondary">Address</span>
                                        <p class="text-primary">
                                            Ground Floor, Valiyara Arcade,<br />
                                            UC College P.O,<br />
                                            Near UC College,<br />
                                            Aluva, Kerala 683102
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="dextheme-col-lg-6 dextehme-col-12 mob">
                        <div class="consultation-form bg-secondary-opaque alt-color">
                            <div class="heading-text">
                                <h4>Write Us a Message</h4>
                                <p>Let’s start your journey toward clearer hearing and confident communication.</p>
                            </div>

                            <div class="dextheme-row gy-4 mb-4">
                                <div class="dextheme-col-lg-12 dextheme-col-md-12">
                                    <input id="wa_name" type="text" placeholder="Your Name" />
                                </div>

                                <div class="dextheme-col-lg-6 dextheme-col-md-12">
                                    <input id="wa_email" type="email" placeholder="Your Email" />
                                </div>

                                <div class="dextheme-col-lg-6 dextheme-col-md-12">
                                    <input id="wa_phone" type="text" placeholder="Phone Number" />
                                </div>

                                <div class="dextheme-col-md-12">
                                    <textarea id="wa_message" rows="5"
                                        placeholder="Tell us your mind here..."></textarea>
                                </div>
                            </div>

                            <button id="wa_send" class="dextheme-btn btn-secondary hover-primary no-effect">
                                Message Us
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="map-container">
            <iframe width="100%" height="450"
                src="https://maps.google.com/maps?q=Aaravam%20Speech%20And%20Hearing%20Aid%20Centre%2C%20Aluva%2C%20Kerala&t=m&z=18&output=embed&iwloc=near"
                style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>

        </div>
    </main>
    <?php include 'footer.php'; ?>
    <script type="text/javascript" src="assets/vendor/js/lightbox-plus-jquery.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/progressbar.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/swiper-bundle.min.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const currentPath = window.location.pathname;

            // Ambil semua link dari navbar
            const allLinks = document.querySelectorAll(
                ".navbar-nav a.nav-link, .navbar-nav a.dropdown-item"
            );

            allLinks.forEach((link) => {
                const href = link.getAttribute("href");

                // Abaikan jika href kosong atau #
                if (!href || href === "#") return;

                // Buat URL absolut dari href
                const linkUrl = new URL(href % 2c % 20window.location.html);

                // Jika cocok dengan path sekarang
                if (linkUrl.pathname === currentPath) {
                    // Tambah active ke link yang cocok
                    link.classList.add("active");

                    // Jika ini dropdown-item, tambahkan active ke parent nav-link-nya
                    const parentDropdown = link.closest(".dropdown");
                    if (parentDropdown) {
                        const parentLink = parentDropdown.querySelector(".nav-link");
                        if (parentLink) {
                            parentLink.classList.add("active");
                        }
                    }
                }
            });
        });
    </script>

    <script>
        (function () {
            // IMPORTANT: replace with your clinic WhatsApp number (international format, no + or spaces)
            const clinicWhatsApp = '919633274214';

            const btn = document.getElementById('wa_send');
            const nameEl = document.getElementById('wa_name');
            const emailEl = document.getElementById('wa_email');
            const phoneEl = document.getElementById('wa_phone');
            const msgEl = document.getElementById('wa_message');

            btn.addEventListener('click', function () {
                const name = (nameEl.value || '').trim();
                const email = (emailEl.value || '').trim();
                const phone = (phoneEl.value || '').trim();
                const message = (msgEl.value || '').trim();

                // Ensure there is something to send
                if (!name && !phone && !message && !email) {
                    alert('Please enter at least one contact detail or a short message so we can get back to you.');
                    return;
                }

                // Build message text
                let text = 'New Consultation Request from Website:%0A';
                if (name) text += '%0A*Name:* ' + encodeURIComponent(name);
                if (email) text += '%0A*Email:* ' + encodeURIComponent(email);
                if (phone) text += '%0A*Phone:* ' + encodeURIComponent(phone);
                if (message) text += '%0A*Concern:* ' + encodeURIComponent(message);

                // Because we encoded each field separately above, join them directly
                // Construct final URL using api.whatsapp.com for broad compatibility
                const url = 'https://api.whatsapp.com/send?phone=' + encodeURIComponent(clinicWhatsApp) + '&text=' + text;

                // Open WhatsApp (web or app)
                window.open(url, '_blank');

                // Optionally clear the form after sending (uncomment if desired)
                // nameEl.value = ''; emailEl.value = ''; phoneEl.value = ''; msgEl.value = '';
            });
        })();
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

    <!-- Appointment Modal -->
    <div class="modal fade" id="appointmentModal" tabindex="-1" aria-labelledby="appointmentModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="appointmentModalLabel">Book an Appointment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="whatsappForm" novalidate>
                        <div class="mb-3">
                            <label for="userName" class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="userName" required>
                            <div class="invalid-feedback">Please enter your name.</div>
                        </div>
                        <div class="mb-3">
                            <label for="userPhone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="userPhone" required pattern="[0-9]{10}">
                            <div class="invalid-feedback">Enter a valid 10-digit phone number.</div>
                        </div>
                        <div class="mb-3">
                            <label for="serviceSelect" class="form-label">Desired Service</label>
                            <select class="form-select" id="serviceSelect" required>
                                <option selected value="">Select a Service</option>
                                <option value="Audiology">Audiology</option>
                                <option value="Speech Therapy">Speech Therapy</option>
                                <option value="Products">Products Enquiry</option>
                                <option value="General Enquiry">General Enquiry</option>
                            </select>
                            <div class="invalid-feedback">Please select a service.</div>
                        </div>
                        <div class="text-center mt-4">
                            <button type="submit" class="dextheme-btn w-100">Send Details</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast-container" class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="toastMessage" class="toast align-items-center text-bg-success border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body" id="toastText">
                    Details sent successfully!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
            </div>
        </div>
    </div>

    <!-- Script -->
    <script>
        const form = document.getElementById('whatsappForm');
        const nameInput = document.getElementById('userName');
        const phoneInput = document.getElementById('userPhone');
        const serviceSelect = document.getElementById('serviceSelect');
        const toastEl = document.getElementById('toastMessage');
        const toastText = document.getElementById('toastText');

        // Bootstrap toast setup
        const toast = new bootstrap.Toast(toastEl, { delay: 3000 });

        // Real-time validation
        form.querySelectorAll('input, select').forEach(field => {
            field.addEventListener('input', () => {
                if (field.checkValidity()) {
                    field.classList.remove('is-invalid');
                    field.classList.add('is-valid');
                } else {
                    field.classList.remove('is-valid');
                    field.classList.add('is-invalid');
                }
            });
        });

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            if (!form.checkValidity()) {
                form.classList.add('was-validated');
                toastText.textContent = "Please fill all required fields correctly.";
                toastEl.classList.remove('text-bg-success');
                toastEl.classList.add('text-bg-danger');
                toast.show();
                return;
            }

            const name = nameInput.value.trim();
            const phone = phoneInput.value.trim();
            const service = serviceSelect.value.trim();
            const recipientNumber = '919633274214';

            const message = `*New Appointment Request (via Website Modal)*%0A%0A` +
                `Name: ${name}%0A` +
                `Phone: ${phone}%0A` +
                `Service: ${service}%0A%0A` +
                `Please help me book an appointment.`;

            try {
                const whatsappUrl = `https://wa.me/${recipientNumber}?text=${message}`;
                window.open(whatsappUrl, '_blank');

                // Success toast
                toastText.textContent = "Details sent successfully!";
                toastEl.classList.remove('text-bg-danger');
                toastEl.classList.add('text-bg-success');
                toast.show();

                // Hide modal & reset form
                const modalElement = document.getElementById('appointmentModal');
                const modalInstance = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
                modalInstance.hide();

                form.reset();
                form.querySelectorAll('.is-valid').forEach(el => el.classList.remove('is-valid'));
            } catch (error) {
                toastText.textContent = "Message not sent. Please try again.";
                toastEl.classList.remove('text-bg-success');
                toastEl.classList.add('text-bg-danger');
                toast.show();
            }
        });
    </script>

</body>

<!-- Mirrored from psikolog-html-preview.dextheme.net/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 08 Oct 2025 04:08:32 GMT -->

</html>