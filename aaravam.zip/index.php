<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from psikolog-html-preview.dextheme.net/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 08 Oct 2025 04:07:09 GMT -->

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Aaravam</title>

  <link rel="icon" type="image/x-icon" href="assets/images/logo/title-icon.png" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap"
    rel="stylesheet">

  <link rel="stylesheet" href="assets/css/main.min.css" />
  <link rel="stylesheet" href="assets/css/custom.html" />
  <link rel="stylesheet" href="assets/vendor/css/ekiticons3b71.css" />
  <link rel="stylesheet" href="assets/vendor/css/animate.min.css" />
  <link rel="stylesheet" href="assets/vendor/css/swiper-bundle.min.css" />
  <link rel="stylesheet" href="assets/vendor/css/lightbox.min.css" />
  <script type="text/javascript" src="assets/vendor/js/bootstrap.js"></script>
  <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap"
    rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
    rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap"
    rel="stylesheet">

</head>

<style>
  /* ------------------------------------------- */
  /* CARD CONTAINER STYLES (Retained/Modified)   */
  /* ------------------------------------------- */
  .dextheme-service-card {
    background-color: #ffffffff;
    border-radius: 10px;
    padding: 30px;
    transition: all 0.3s ease;
    border: 1px solid #c6c6c6ff;

    width: 310px;
    height: 400px;
    position: relative;
    /* Added for positioning the arrow button */
    overflow: hidden;
    /* Ensures content stays within bounds */
  }

  .dextheme-service-card:hover {
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.15);
    transform: translateY(-3px);
    border-color: #007bff;
  }

  /* ------------------------------------------- */
  /* IMAGE CENTERING AND DESKTOP SIZE          */
  /* ------------------------------------------- */
  .dextheme-service-card .card-content {
    /* Ensures H4 and P tags are centered if needed, and sets up image centering */
    text-align: center;
  }

  .dextheme-service-card .card-content img {
    /* 1. Centering for Block Elements */
    display: block;
    margin: 0 auto 20px auto;
    /* 0 top/bottom, auto left/right for centering, 20px bottom space */

    /* 2. Fixed Size for Desktop/Default (Screens > 767px) */
    /* Adjust these values for your desired desktop size */


    /* 3. Ensures image maintains aspect ratio within the fixed box */
    object-fit: contain;
  }

  /* ------------------------------------------- */
  /* NEW ARROW BUTTON STYLES (Adjusted)         */
  /* ------------------------------------------- */
  .arrow-button-container {
    position: absolute;
    top: 15px;
    right: 15px;
    width: 40px;
    height: 40px;
    background-color: #0096ff;
    /* Button background color */
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    transition: all 0.3s ease;
    z-index: 10;
    /* Ensure it's above other content */
    opacity: 1;
    /* Always visible */
    transform: scale(1);
    /* Always at normal size */
    box-shadow: 0 3px 3px rgba(0, 0, 0, 0.2);
    /* Slight default shadow */
  }

  .arrow-button-container:hover {
    background-color: #0056b3;
    /* Darker blue on hover */
    box-shadow: 0 0 3px rgba(0, 123, 255, 0.7);
    /* More prominent glow on hover */
    transform: scale(1.05);
    /* Slightly scale up on hover */
  }

  .arrow-button-container .arrow-icon {
    width: 20px;
    height: 20px;
    color: white;
    /* Arrow color */
    transition: transform 0.3s ease;
  }

  .arrow-button-container:hover .arrow-icon {
    transform: translate(3px, -3px);
    /* Move arrow slightly on hover */
  }

  /* Loading animation */
  .dextheme-service-card.loading .arrow-button-container {
    animation: pulse 1s infinite alternate;
    /* Apply pulse animation when card has 'loading' class */
  }

  @keyframes pulse {
    0% {
      transform: scale(1);
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    }

    100% {
      transform: scale(1.05);
      /* Slightly larger */
      box-shadow: 0 0 15px rgba(0, 123, 255, 0.8);
      /* Stronger glow */
    }
  }


  /* ------------------------------------------- */
  /* MOBILE VIEW STYLES (Max width 767px)          */
  /* ------------------------------------------- */
  @media (max-width: 767px) {
    .dextheme-service-card {
      /* Fixed Size for Mobile (Screens <= 767px) */
      /* Adjust these values for your desired mobile size */
      width: 350px;
      height: 420px;

      /* Optional: Adjust margin for mobile if necessary */
      margin-bottom: 15px;
    }

    .dextheme-col-12 {
      display: flex;
      justify-content: center;
    }
  }

  /* Remove the old learn more link */
  .dextheme-service-card .service-action {
    display: none;
  }


  /* Styling for the main banner container */
  .call-to-action-banner {
    width: 100%;
    /* The height/padding will depend on surrounding content, 
       but this ensures it's centered and has a white background */
    padding: 30px 0;
    text-align: center;
    background-color: #ffffff;
    /* White background */
    /* Optional: A subtle top border if needed */
  }

  /* Styling for the text */
  .call-to-action-banner p {
    font-size: 16px;
    /* Adjust as needed */
    line-height: 1.5;
    color: #333333;
    /* Dark gray for the text */
    /* Ensure the text is centered within the banner */
    display: inline-block;
  }

  /* Styling for the phone number link */
  .phone-link-underline {
    /* Remove default browser underline */
    text-decoration: none;

    /* Use a border for a custom, solid underline */
    border-bottom: 1px solid #333333;
    /* 1px solid dark gray line */

    /* Inherit text color from the parent <p> or set explicitly */
    color: inherit;

    /* Optional: Small padding below the text to separate it from the line */
    padding-bottom: 1px;

    /* Optional: Change color on hover for better user experience */
    transition: color 0.3s, border-color 0.3s;
  }

  .phone-link-underline:hover {
    color: #000000;
    /* Darker on hover */
    border-bottom-color: #000000;
  }


  /* brands */

  .logo-slide-box {
    height: 110px;
    /* uniform height */
    width: 220px;
    /* consistent width */
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #fff;
    border: 1px solid #ccc;
    /* subtle gray border */
    border-radius: 6px;
    /* slightly rounded corners */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    /* soft shadow for depth */
    padding: 20px;
    margin: 10px;
    /* spacing between boxes */
    box-sizing: border-box;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }



  /* Image styling */
  .logo-slide-box img {
    max-height: 60px;
    width: auto;
    object-fit: contain;
  }

  /* Center heading and section */
  .client-logo-section {
    background-color: #fff;
    padding: 50px 0;
    text-align: center;
  }

  .client-logo-section h2 {
    color: #777;
    font-weight: 500;
    font-size: 28px;
    margin-bottom: 40px;
  }

  /* Align all slides properly within swiper */
  .dextheme-swiper .swiper-wrapper {
    align-items: center;
  }
</style>

<body>

  <?php include 'header.php'; ?>

  <div class="backdrop" id="drawerBackdrop"></div>
  <main class="bg-white">
    <section class="hero-banner" style="background-image: image: url(assets/images/slider/slider-1.jpg)">
      <div class="dextheme-container">
        <div class="row" style="justify-content: center;">
          <div class="dextheme-col-lg-8 dextheme-col-md-12">
            <div class="hero-banner-content" style="text-align: center">

              <h1 class="heading-title dextheme-animation" data-animate="animate__slideInLeft" style="color: #ffffff">
                Expert Speech & Hearing Care in Kochi.
              </h1>
              <p class="dextheme-animation ft" data-animate="animate__slideInLeft" data-delay-step="220ms" style="color: #ffffff">
                Gain the ability to enjoy conversations, hear your loved ones clearly, and fully engage<br> with the
                world
                around you.
                Your journey to better hearing starts now.
              </p>

              <button class="dextheme-btn btn-primary hover-normal dextheme-animation mob-none" data-bs-toggle="modal"
                data-bs-target="#appointmentModal" type="button" data-animate="animate__slideInLeft"
                data-delay-step="210ms" style="border-radius: 25px">
                Book Appointment
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="dextheme-section-padding bg-secondary-opaque">
      <div class="dextheme-container">
        <div class="d-flex flex-wrap g-4">
          <div class="dextheme-w-35 dextheme-animation" data-animate="animate__slideInLeft">
            <div class="heading-section dextheme-w-90 home-heading">

              <h1 class="heading-title" style="text-decoration: underline; color: black;">
                Empowering You to Hear and Speak Clearly.
              </h1>
            </div>
          </div>
          <div class="dextheme-w-65">
            <div class="dextheme-row mx-lg-4">
              <div class="dextheme-col-lg-4 dextheme-col-md-12 px-lg-3 dextheme-animation"
                data-animate="animate__slideInUp" data-delay-step="200ms">
                <div class="image-box-container">
                  <img src="assets/images/CS79RA3a1.png" />
                  <div class="image-box-content">
                    <h4>Comprehensive Clinical Excellence</h4>
                    <p>
                      Our licensed staff ensures accurate diagnosis and effective treatment by adhering to the highest
                      clinical standards.
                    </p>
                  </div>
                </div>
              </div>
              <div class="dextheme-col-lg-4 dextheme-col-md-12 px-lg-3 dextheme-animation"
                data-animate="animate__slideInUp" data-delay-step="210ms">
                <div class="image-box-container">
                  <img src="assets/images/CS79RA3b1.png" />
                  <div class="image-box-content">
                    <h4>Personalized Aid Selection</h4>
                    <p>
                      Experience advanced, discreet hearing aids with the latest technology for superior sound quality
                      and maximum personal comfort.
                    </p>
                  </div>
                </div>
              </div>
              <div class="dextheme-col-lg-4 dextheme-col-md-12 px-lg-3 dextheme-animation"
                data-animate="animate__slideInUp" data-delay-step="220ms">
                <div class="image-box-container">
                  <img src="assets/images/CS79RA3c1.png" />
                  <div class="image-box-content">
                    <h4>Advanced Hearing Diagnostics</h4>
                    <p>
                      We perform comprehensive hearing tests to accurately assess your hearing health and clearly
                      identify your specific communication needs.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="dextheme-section-padding bg-secondary-opaque-2 bg-white">
      <div class="dextheme-container">
        <div class="heading-section text-center mb-5 dextheme-w-65 mx-auto">

          <h1 class="heading-title mb-4" style="color: black; line-height: 48px;">Top <span class="ud-text">Speech
              Language Therapy</span><br>
            Hospital in Kochi</h1>

        </div>
        <div class="dextheme-row g-4 mb-4">
          <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
            <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
              <div class="card-content">
                <img src="assets/images/icon/autism-disorder.png" />
                <h4 class="text-primary">Autism Spectrum Disorder</h4>
                <p>
                  Specialized support for communication, social skills, and self-regulation across the spectrum.
                </p>
              </div>
              <span class="separator-wavy"></span>
              <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Autism Spectrum Disorder in Speech Therapy"
                target="_blank" class="arrow-button-container">
                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7"></line>
                  <polyline points="7 7 17 7 17 17"></polyline>
                </svg>
              </a>
            </div>
          </div>

          <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
            <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
              <div class="card-content">
                <img src="assets/images/icon/language.png" />
                <h4 class="text-primary">Language Disorder</h4>
                <p>
                  Improve the understanding (receptive) and the effective use (expressive) of language through therapy.
                </p>
              </div>
              <span class="separator-wavy"></span>
              <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Language Disorder in Speech Therapy"
                target="_blank" class="arrow-button-container">
                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7"></line>
                  <polyline points="7 7 17 7 17 17"></polyline>
                </svg>
              </a>
            </div>
          </div>

          <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
            <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
              <div class="card-content">
                <img src="assets/images/icon/specific-learning.png" />
                <h4 class="text-primary">Specific Learning Disorder</h4>
                <p>
                  Customized strategies to help individuals overcome challenges in reading, writing, and math skills.
                </p>
              </div>
              <span class="separator-wavy"></span>
              <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Specific Learning Disorder in Speech Therapy"
                target="_blank" class="arrow-button-container">
                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7"></line>
                  <polyline points="7 7 17 7 17 17"></polyline>
                </svg>
              </a>
            </div>
          </div>

          <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
            <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
              <div class="card-content">
                <img src="assets/images/icon/speech-disorder.png" />
                <h4 class="text-primary">Speech Sound Disorder</h4>
                <p>
                  Therapy dedicated to improving articulation and clarity for fully intelligible speech.
                </p>
              </div>
              <span class="separator-wavy"></span>
              <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Speech Sound Disorder in Speech Therapy"
                target="_blank" class="arrow-button-container">
                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7"></line>
                  <polyline points="7 7 17 7 17 17"></polyline>
                </svg>
              </a>
            </div>
          </div>

          <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
            <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
              <div class="card-content">
                <img src="assets/images/icon/cleft-lip.png" />
                <h4 class="text-primary">Cleft Lips / Palate</h4>
                <p>
                  Comprehensive support for individuals with cleft conditions, addressing speech, feeding, and
                  developmental needs.
                </p>
              </div>
              <span class="separator-wavy"></span>
              <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Cleft Lips / Palate in Speech Therapy"
                target="_blank" class="arrow-button-container">
                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7"></line>
                  <polyline points="7 7 17 7 17 17"></polyline>
                </svg>
              </a>
            </div>
          </div>

          <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
            <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
              <div class="card-content">
                <img src="assets/images/icon/fluency-disorder.png" />
                <h4 class="text-primary">Fluency Disorder</h4>
                <p>
                  Specialized therapy to help manage stuttering and other fluency challenges, enhancing smooth,
                  confident speech.
                </p>
              </div>
              <span class="separator-wavy"></span>
              <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Fluency Disorder in Speech Therapy"
                target="_blank" class="arrow-button-container">
                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7"></line>
                  <polyline points="7 7 17 7 17 17"></polyline>
                </svg>
              </a>
            </div>
          </div>

          <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
            <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
              <div class="card-content">
                <img src="assets/images/icon/cluttering.png" />
                <h4 class="text-primary">Cluttering</h4>
                <p>
                  Improve speech clarity and rhythm by addressing rapid or disorganized speech patterns through focused
                  intervention.
                </p>
              </div>
              <span class="separator-wavy"></span>
              <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Cluttering in Speech Therapy"
                target="_blank" class="arrow-button-container">
                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7"></line>
                  <polyline points="7 7 17 7 17 17"></polyline>
                </svg>
              </a>
            </div>
          </div>

          <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
            <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
              <div class="card-content">
                <img src="assets/images/icon/down-syndrome.png" />
                <h4 class="text-primary">Down Syndrome</h4>
                <p>
                  Tailored therapeutic programs to support communication, motor skills, and cognitive development for
                  individuals.
                </p>
              </div>
              <span class="separator-wavy"></span>
              <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Down Syndrome in Speech Therapy"
                target="_blank" class="arrow-button-container">
                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                  stroke-linecap="round" stroke-linejoin="round">
                  <line x1="7" y1="17" x2="17" y2="7"></line>
                  <polyline points="7 7 17 7 17 17"></polyline>
                </svg>
              </a>
            </div>
          </div>

        </div>
        <div class="call-to-action-banner">
          <p>
            We are here to help you achieve fluency and effective voice control.
            <a href="speech-therapy.php" class="phone-link-underline">Know more</a>
          </p>
        </div>

      </div>
    </section>


    <section class="dextheme-section-padding bg-lightblue">
      <div class="dextheme-container">
        <div class="dextheme-row g-5">
          <div class="dextheme-col-lg-6 dextheme-col-md-12">
            <div class="stack-images" style="background-image: url(assets/images/aaravam/hearing-therapy.jpg)" img
              src="assets/images/aaravam/audiology.png">


            </div>
          </div>
          <div class="dextheme-col-lg-6 dextheme-col-md-12">
            <div class="heading-section mb-5 mt-4">

              <h1 class="heading-title mb-4 dextheme-animation" data-animate="animate__slideInLeft"
                data-delay-step="200ms">
                Expert Hearing Test & Hearing Aid Clinic in Kochi
              </h1>
              <p class="dextheme-animation" data-animate="animate__slideInLeft" data-delay-step="210ms"
                style="color: black">
                At our Hearing Test and Hearing Aid Clinic in Kochi, we offer complete hearing care services including
                diagnostic hearing tests, hearing aid consultations, fittings, and aftercare. Our team of experienced
                audiologists uses advanced equipment to ensure accurate results and personalized hearing solutions.
              </p>
            </div>
            <div class="dextheme-row">
              <div class="dextheme-col-lg-6 dextheme-col-md-12">
                <h4 class="text-primary mb-3 bb-g">Your trusted Hearing Test Specialists</h4>
                <p class="text-dark">
                  Precise hearing evaluation using modern audiology technology. Identify hearing issues early with expert testing and guidance.
                </p>
              </div>
              <div class="dextheme-col-lg-6 dextheme-col-md-12">
                <h4 class="text-primary mb-3 bb-g">Advanced Technology <br class="mdno">& Care</h4>
                <p class="text-dark">
                  Personalized hearing solutions designed to match your lifestyle and comfort. Advanced technology & professional care.
                </p>
              </div>
              <!-- <div class="dextheme-col-md-12 mt-lg-4">
                <div class="quotes dextheme-animation" data-animate="animate__slideInLeft" data-delay-step="220ms">
                  <h4 class="text-primary mb-3 pt-2">
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Ut elit tellus, luctus nec ullamcorper mattis, pulvinar
                    dapibus leo."
                  </h4>
                  <p>Alex Morgan., Psycholog</p>
                </div>
              </div> -->
            </div>
            <a href="audiology.php" class="dextheme-btn btn-primary hover-normal mt-3 mb-4 dextheme-animation"
              data-animate="animate__slideInLeft" data-delay-step="230ms" style="border-radius: 25px;">
              Find Out More
            </a>
          </div>
        </div>
      </div>
    </section>
    <section class="client-logo-section ">
      <div class="dextheme-container">
        <h2 class="text-center mb-5">Our Partnered Hearing Aid Brands</h2>
        <div data-swiper-active data-swiper-slides-per-view="5" data-swiper-space-between="45" data-swiper-loop="true"
          data-swiper-autoplay-delay="3000" data-swiper-navigation="false"
          data-swiper-breakpoints='{"320": {"slidesPerView": 2}, "768": {"slidesPerView": 4}}'>
          <div class="dextheme-swiper swiper-fade position-relative overflow-hidden mb-5">
            <div class="swiper-wrapper">
              <div class="swiper-slide logo-slide-box">
                <img src="assets/images/brand/phonak.png" alt="Phonak">
              </div>
              <div class="swiper-slide logo-slide-box">
                <img src="assets/images/brand/resound.png" alt="ReSound">
              </div>
              <div class="swiper-slide logo-slide-box">
                <img src="assets/images/brand/signia.png" alt="Signia">
              </div>
              <div class="swiper-slide logo-slide-box">
                <img src="assets/images/brand/unitron.png" alt="Unitron">
              </div>
              <div class="swiper-slide logo-slide-box">
                <img src="assets/images/brand/widex.png" alt="Widex">
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>

    <section class=" sm-pt-50px" style="padding-top: 80px; padding-bottom: 80px; background-color: #efefef;">
      <div class="container">
        <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner">

            <!-- Testimonial 1 -->
            <div class="carousel-item active">
              <div class="row g-0 overflow-hidden">
                <div
                  class="col-12 cover-background border-radius-6px position-relative d-flex align-items-stretch jc-center">
                  <div class="row w-100">
                    <div class="col-lg-3 col-md-12 p-0 d-flex justify-content-center imgg">
                      <img src="assets/images/aaravam/letter-e.png" alt="" class="img-fluid  border-radius-6px"
                        style="width: 150px;height: 150px !important;">
                    </div>
                    <div class="col-lg-9 col-md-12 p-3">
                      <div class="fs-140 alt-font text-base-color d-block lh-34">“</div>
                      <h6 class="sm-w-100 text-black alt-font lh-40 mb-25px ">
                        The guidance I received here
                        has truly transformed my life.
                        I've found peace, clarity, and
                        balance thanks to their
                        compassionate approach.
                      </h6>
                      <div class="text-base-color fs-16 fw-600 ls-1px text-uppercase position-relative z-index-2">
                        Emma
                        Johnson</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Testimonial 2 -->
            <div class="carousel-item">
              <div class="row g-0 overflow-hidden">
                <div
                  class="col-12 cover-background border-radius-6px position-relative d-flex align-items-stretch jc-center">
                  <div class="row w-100">
                    <div class="col-lg-3 col-md-12 p-0 d-flex justify-content-center imgg">
                      <img src="assets/images/aaravam/letter-e.png" alt="" class="img-fluid border-radius-6px"
                        style="width: 150px;height: 150px !important;">
                    </div>
                    <div class="col-lg-9 col-md-12 p-3">
                      <div class="fs-140 alt-font text-base-color d-block lh-34">“</div>
                      <h6 class="sm-w-100 text-black alt-font lh-40 mb-25px ">
                        The guidance I received here
                        has truly transformed my life.
                        I've found peace, clarity, and
                        balance thanks to their
                        compassionate approach.
                      </h6>
                      <div class="text-base-color fs-16 fw-600 ls-1px text-uppercase position-relative z-index-2">
                        Emma
                        Johnson</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Testimonial 3 -->
            <div class="carousel-item">
              <div class="row g-0 overflow-hidden">
                <div
                  class="col-12 cover-background border-radius-6px position-relative d-flex align-items-stretch jc-center">
                  <div class="row w-100">
                    <div class="col-lg-3 col-md-12 p-0 d-flex justify-content-center imgg">
                      <img src="assets/images/aaravam/letter-e.png" alt="" class="img-fluid border-radius-6px"
                        style="width: 150px;height: 150px !important;">
                    </div>
                    <div class="col-lg-9 col-md-12 p-3">
                      <div class="fs-140 alt-font text-base-color d-block lh-34">“</div>
                      <h6 class="sm-w-100 text-black alt-font lh-40 mb-25px ">
                        The guidance I received here
                        has truly transformed my life.
                        I've found peace, clarity, and
                        balance thanks to their
                        compassionate approach.
                      </h6>
                      <div class="text-base-color fs-16 fw-600 ls-1px text-uppercase position-relative z-index-2">
                        Emma
                        Johnson</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Controls -->
            <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel"
              data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel"
              data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </button>
          </div>
        </div>
    </section>



  </main>
  <?php include 'footer.php'; ?>
  <script type="text/javascript" src="assets/vendor/js/lightbox-plus-jquery.min.js"></script>
  <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
  <script type="text/javascript" src="assets/vendor/js/progressbar.min.js"></script>
  <script type="text/javascript" src="assets/vendor/js/swiper-bundle.min.js"></script>
  <script type="text/javascript" src="assets/js/main.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const currentPath = window.location.pathname;

      // Ambil semua link dari navbar
      const allLinks = document.querySelectorAll('.navbar-nav a.nav-link, .navbar-nav a.dropdown-item');

      allLinks.forEach(link => {
        const href = link.getAttribute('href');

        // Abaikan jika href kosong atau #
        if (!href || href === '#') return;

        // Buat URL absolut dari href
        const linkUrl = new URL(hrefcwindow.location.html);

        // Jika cocok dengan path sekarang
        if (linkUrl.pathname === currentPath) {
          // Tambah active ke link yang cocok
          link.classList.add('active');

          // Jika ini dropdown-item, tambahkan active ke parent nav-link-nya
          const parentDropdown = link.closest('.dropdown');
          if (parentDropdown) {
            const parentLink = parentDropdown.querySelector('.nav-link');
            if (parentLink) {
              parentLink.classList.add('active');
            }
          }
        }
      });
    });
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>

  <!-- Appointment Modal -->
  <div class="modal fade" id="appointmentModal" tabindex="-1" aria-labelledby="appointmentModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="appointmentModalLabel">Book an Appointment</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="whatsappForm" novalidate>
            <div class="mb-3">
              <label for="userName" class="form-label">Your Name</label>
              <input type="text" class="form-control" id="userName" required>
              <div class="invalid-feedback">Please enter your name.</div>
            </div>
            <div class="mb-3">
              <label for="userPhone" class="form-label">Phone Number</label>
              <input type="tel" class="form-control" id="userPhone" required pattern="[0-9]{10}">
              <div class="invalid-feedback">Enter a valid 10-digit phone number.</div>
            </div>
            <div class="mb-3">
              <label for="serviceSelect" class="form-label">Desired Service</label>
              <select class="form-select" id="serviceSelect" required>
                <option selected value="">Select a Service</option>
                <option value="Audiology">Audiology</option>
                <option value="Speech Therapy">Speech Therapy</option>
                <option value="Products">Products Enquiry</option>
                <option value="General Enquiry">General Enquiry</option>
              </select>
              <div class="invalid-feedback">Please select a service.</div>
            </div>
            <div class="text-center mt-4">
              <button type="submit" class="dextheme-btn w-100">Send Details</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Toast Notification -->
  <div id="toast-container" class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="toastMessage" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive"
      aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body" id="toastText">
          Details sent successfully!
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
          aria-label="Close"></button>
      </div>
    </div>
  </div>

  <!-- Script -->
  <script>
    const form = document.getElementById('whatsappForm');
    const nameInput = document.getElementById('userName');
    const phoneInput = document.getElementById('userPhone');
    const serviceSelect = document.getElementById('serviceSelect');
    const toastEl = document.getElementById('toastMessage');
    const toastText = document.getElementById('toastText');

    // Bootstrap toast setup
    const toast = new bootstrap.Toast(toastEl, { delay: 3000 });

    // Real-time validation
    form.querySelectorAll('input, select').forEach(field => {
      field.addEventListener('input', () => {
        if (field.checkValidity()) {
          field.classList.remove('is-invalid');
          field.classList.add('is-valid');
        } else {
          field.classList.remove('is-valid');
          field.classList.add('is-invalid');
        }
      });
    });

    form.addEventListener('submit', function (event) {
      event.preventDefault();

      if (!form.checkValidity()) {
        form.classList.add('was-validated');
        toastText.textContent = "Please fill all required fields correctly.";
        toastEl.classList.remove('text-bg-success');
        toastEl.classList.add('text-bg-danger');
        toast.show();
        return;
      }

      const name = nameInput.value.trim();
      const phone = phoneInput.value.trim();
      const service = serviceSelect.value.trim();
      const recipientNumber = '919633274214';

      const message = `*New Appointment Request (via Website Modal)*%0A%0A` +
        `Name: ${name}%0A` +
        `Phone: ${phone}%0A` +
        `Service: ${service}%0A%0A` +
        `Please help me book an appointment.`;

      try {
        const whatsappUrl = `https://wa.me/${recipientNumber}?text=${message}`;
        window.open(whatsappUrl, '_blank');

        // Success toast
        toastText.textContent = "Details sent successfully!";
        toastEl.classList.remove('text-bg-danger');
        toastEl.classList.add('text-bg-success');
        toast.show();

        // Hide modal & reset form
        const modalElement = document.getElementById('appointmentModal');
        const modalInstance = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
        modalInstance.hide();

        form.reset();
        form.querySelectorAll('.is-valid').forEach(el => el.classList.remove('is-valid'));
      } catch (error) {
        toastText.textContent = "Message not sent. Please try again.";
        toastEl.classList.remove('text-bg-success');
        toastEl.classList.add('text-bg-danger');
        toast.show();
      }
    });
  </script>


</body>



</html>