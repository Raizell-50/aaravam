<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from psikolog-html-preview.dextheme.net/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 08 Oct 2025 04:08:20 GMT -->

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Aaravam</title>

    <link rel="icon" type="image/x-icon" href="assets/images/logo/title-icon.png" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="assets/css/main.min.css" />
    <link rel="stylesheet" href="assets/css/custom.html" />
    <link rel="stylesheet" href="assets/vendor/css/ekiticons3b71.css" />
    <link rel="stylesheet" href="assets/vendor/css/animate.min.css" />
    <link rel="stylesheet" href="assets/vendor/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/vendor/css/lightbox.min.css" />
    <script type="text/javascript" src="assets/vendor/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap"
        rel="stylesheet">
</head>
<style>
    /* ------------------------------------------- */
    /* CARD CONTAINER STYLES (Retained/Modified)   */
    /* ------------------------------------------- */
    .dextheme-service-card {
        background-color: #ffffffff;
        border-radius: 10px;
        padding: 30px;
        transition: all 0.3s ease;
        border: 1px solid #c6c6c6ff;

        width: 310px;
        height: 400px;
        position: relative;
        /* Added for positioning the arrow button */
        overflow: hidden;
        /* Ensures content stays within bounds */
    }

    .dextheme-service-card:hover {
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.15);
        transform: translateY(-3px);
        border-color: #007bff;
    }

    /* ------------------------------------------- */
    /* IMAGE CENTERING AND DESKTOP SIZE          */
    /* ------------------------------------------- */
    .dextheme-service-card .card-content {
        /* Ensures H4 and P tags are centered if needed, and sets up image centering */
        text-align: center;
    }

    .dextheme-service-card .card-content img {
        /* 1. Centering for Block Elements */
        display: block;
        margin: 0 auto 20px auto;
        /* 0 top/bottom, auto left/right for centering, 20px bottom space */

        /* 2. Fixed Size for Desktop/Default (Screens > 767px) */
        /* Adjust these values for your desired desktop size */


        /* 3. Ensures image maintains aspect ratio within the fixed box */
        object-fit: contain;
    }

    /* ------------------------------------------- */
    /* NEW ARROW BUTTON STYLES (Adjusted)         */
    /* ------------------------------------------- */
    .arrow-button-container {
        position: absolute;
        top: 15px;
        right: 15px;
        width: 40px;
        height: 40px;
        background-color: #0096ff;
        /* Button background color */
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        transition: all 0.3s ease;
        z-index: 10;
        /* Ensure it's above other content */
        opacity: 1;
        /* Always visible */
        transform: scale(1);
        /* Always at normal size */
        box-shadow: 0 3px 3px rgba(0, 0, 0, 0.2);
        /* Slight default shadow */
    }

    .arrow-button-container:hover {
        background-color: #0056b3;
        /* Darker blue on hover */
        box-shadow: 0 0 3px rgba(0, 123, 255, 0.7);
        /* More prominent glow on hover */
        transform: scale(1.05);
        /* Slightly scale up on hover */
    }

    .arrow-button-container .arrow-icon {
        width: 20px;
        height: 20px;
        color: white;
        /* Arrow color */
        transition: transform 0.3s ease;
    }

    .arrow-button-container:hover .arrow-icon {
        transform: translate(3px, -3px);
        /* Move arrow slightly on hover */
    }

    /* Loading animation */
    .dextheme-service-card.loading .arrow-button-container {
        animation: pulse 1s infinite alternate;
        /* Apply pulse animation when card has 'loading' class */
    }

    @keyframes pulse {
        0% {
            transform: scale(1);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        100% {
            transform: scale(1.05);
            /* Slightly larger */
            box-shadow: 0 0 15px rgba(0, 123, 255, 0.8);
            /* Stronger glow */
        }
    }


    /* ------------------------------------------- */
    /* MOBILE VIEW STYLES (Max width 767px)          */
    /* ------------------------------------------- */
    @media (max-width: 767px) {
        .dextheme-service-card {
            /* Fixed Size for Mobile (Screens <= 767px) */
            /* Adjust these values for your desired mobile size */
            width: 350px;
            height: 420px;

            /* Optional: Adjust margin for mobile if necessary */
            margin-bottom: 15px;
        }

        .dextheme-col-12 {
            display: flex;
            justify-content: center;
        }
    }

    /* Remove the old learn more link */
    .dextheme-service-card .service-action {
        display: none;
    }


    /* Styling for the main banner container */
    .call-to-action-banner {
        width: 100%;
        /* The height/padding will depend on surrounding content, 
       but this ensures it's centered and has a white background */
        padding: 30px 0;
        text-align: center;
        background-color: #ffffff;
        /* White background */
        /* Optional: A subtle top border if needed */
    }

    /* Styling for the text */
    .call-to-action-banner p {
        font-size: 16px;
        /* Adjust as needed */
        line-height: 1.5;
        color: #333333;
        /* Dark gray for the text */
        /* Ensure the text is centered within the banner */
        display: inline-block;
    }

    /* Styling for the phone number link */
    .phone-link-underline {
        /* Remove default browser underline */
        text-decoration: none;

        /* Use a border for a custom, solid underline */
        border-bottom: 1px solid #333333;
        /* 1px solid dark gray line */

        /* Inherit text color from the parent <p> or set explicitly */
        color: inherit;

        /* Optional: Small padding below the text to separate it from the line */
        padding-bottom: 1px;

        /* Optional: Change color on hover for better user experience */
        transition: color 0.3s, border-color 0.3s;
    }

    .phone-link-underline:hover {
        color: #000000;
        /* Darker on hover */
        border-bottom-color: #000000;
    }
</style>
<?php include 'header.php'; ?>

<body>

    <div class="backdrop" id="drawerBackdrop"></div>
    <main class="bg-white">
        <section class="heading-wrapper">
            <div class="dextheme-container">
                <div class="title-breadcrumb">
                    <h2>Speech Therapy</h2>
                    <div class="breadcrumb-wrapper">
                        <p><a href="index.php">Home</a> - Speech Therapy</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="dextheme-section-padding bg-secondary-opaque-2 bg-white">
            <div class="dextheme-container">
                <div class="heading-section text-center mb-5 dextheme-w-65 mx-auto">

                    <h1 class="heading-title mb-4" style="color: black; line-height: 48px;">Top <span
                            class="ud-text">Speech
                            Language Therapy</span><br>
                        Hospital in Kochi</h1>

                </div>
                <div class="dextheme-row g-4 mb-4">
                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/autism-disorder.png" />
                                <h4 class="text-primary">Autism Spectrum Disorder</h4>
                                <p>
                                    Specialized support for communication, social skills, and self-regulation across the
                                    spectrum.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Autism Spectrum Disorder in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/language.png" />
                                <h4 class="text-primary">Language Disorder</h4>
                                <p>
                                    Improve the understanding (receptive) and the effective use (expressive) of language
                                    through therapy.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Language Disorder in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/specific-learning.png" />
                                <h4 class="text-primary">Specific Learning Disorder</h4>
                                <p>
                                    Customized strategies to help individuals overcome challenges in reading, writing,
                                    and math skills.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Specific Learning Disorder in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/speech-disorder.png" />
                                <h4 class="text-primary">Speech Sound Disorder</h4>
                                <p>
                                    Therapy dedicated to improving articulation and clarity for fully intelligible
                                    speech.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Speech Sound Disorder in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/cleft-lip.png" />
                                <h4 class="text-primary">Cleft Lips / Palate</h4>
                                <p>
                                    Comprehensive support for individuals with cleft conditions, addressing speech,
                                    feeding, and
                                    developmental needs.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Cleft Lips / Palate in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/fluency-disorder.png" />
                                <h4 class="text-primary">Fluency Disorder</h4>
                                <p>
                                    Specialized therapy to help manage stuttering and other fluency challenges,
                                    enhancing smooth,
                                    confident speech.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Fluency Disorder in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/cluttering.png" />
                                <h4 class="text-primary">Cluttering</h4>
                                <p>
                                    Improve speech clarity and rhythm by addressing rapid or disorganized speech
                                    patterns through focused
                                    intervention.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Cluttering in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/down-syndrome.png" />
                                <h4 class="text-primary">Down Syndrome</h4>
                                <p>
                                    Tailored therapeutic programs to support communication, motor skills, and cognitive
                                    development for
                                    individuals.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Down Syndrome in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/palsy.png" />
                                <h4 class="text-primary">Cerebral Palsy</h4>
                                <p>
                                    Therapeutic support to address communication, motor skill, and feeding challenges
                                    associated with cerebral palsy.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Cerebral Palsy in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/delay.png" />
                                <h4 class="text-primary">Global Development Delay</h4>
                                <p>
                                    Early intervention and therapy to support children facing significant delays in
                                    multiple developmental areas.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Global Development Delay in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/intellectual-disability.png" />
                                <h4 class="text-primary">Intellectual Disability</h4>
                                <p>
                                    Tailored strategies to enhance cognitive, adaptive, and communication skills,
                                    fostering greater independence.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Intellectual Disability in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/hyperactivity.png" />
                                <h4 class="text-primary">Hyperactivity Disorder</h4>
                                <p>
                                    Behavioral and communication strategies to help individuals manage attention,
                                    impulsivity, and hyperactivity challenges.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Hyperactivity Disorder in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/virtual-autism.png" />
                                <h4 class="text-primary">Virtual Autism</h4>
                                <p>
                                    Support for children exhibiting autism-like traits due to excessive screen time,
                                    focusing on developmental redirection.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Virtual Autism in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/communication-disorder.png" />
                                <h4 class="text-primary">Social Communication Disorder</h4>
                                <p>
                                    Therapy to improve social interaction, understanding social cues, and the pragmatic
                                    use of language in various contexts.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Social Communication Disorder in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/voice-therapy.png" />
                                <h4 class="text-primary">Voice Therapy</h4>
                                <p>
                                    Specialized programs to improve vocal quality, pitch, and loudness for individuals
                                    with various voice disorders.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Voice Therapy in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/stroke.png" />
                                <h4 class="text-primary">Stroke Disabilities</h4>
                                <p>
                                    Rehabilitation therapy to help individuals regain speech, language, and cognitive
                                    functions affected by stroke.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Stroke Disabilities in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/aphasia.png" />
                                <h4 class="text-primary">Aphasia/Dysarthia</h4>
                                <p>
                                    Therapy to regain language skills (aphasia) and improve speech muscle control
                                    (dysarthria) following brain injury.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Aphasia/Dysarthia in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/dysphagia.png" />
                                <h4 class="text-primary">Dysphagia</h4>
                                <p>
                                    Specialized intervention to safely manage and improve swallowing function in
                                    individuals with feeding and swallowing difficulties.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Dysphagia in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="dextheme-col-lg-3 dextheme-col-md-6 dextheme-col-12">
                        <div class="dextheme-service-card dextheme-animation" data-animate="animate__slideInUp">
                            <div class="card-content">
                                <img src="assets/images/icon/hearing-loss.png" />
                                <h4 class="text-primary">Hearing Loss</h4>
                                <p>
                                    Comprehensive assessment and management strategies, including fitting and counseling
                                    for all degrees of hearing loss.
                                </p>
                            </div>
                            <span class="separator-wavy"></span>
                            <a href="https://wa.me/919633274214?text=Hello, I would like to know more about Speech Problem throughHearing Loss in Speech Therapy"
                                target="_blank" class="arrow-button-container">
                                <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>

                </div>


            </div>
        </section>

        <section class="consultation-section bg-lightgray">
            <div class="dextheme-container">
                <div class="dextheme-row">
                    <div class="dextheme-col-lg-6 dextheme-col-md-12">
                        <div class="contact-info">
                            <div class="heading-section mb-4">
                                <h5 class="heading-subtitle dextheme-animation" data-animate="animate__slideInLeft">
                                    Always Here for You
                                </h5>
                                <h1 class="heading-title mb-4 dextheme-animation" data-animate="animate__slideInLeft"
                                    style="font-size: 43px;">
                                    Your Journey to Better Hearing Starts Here
                                </h1>
                                <p class="dextheme-animation" data-animate="animate__slideInLeft">
                                    Discover the joy of clear conversations and confident communication. Our expert
                                    audiologists are here to help you hear and speak better, every day.
                                </p>
                            </div>
                            <div class="contact-info-list pt-3">
                                <div class="info-item dextheme-animation" data-animate="animate__slideInLeft">
                                    <span class="info-icon">
                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-phone-alt"
                                            viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z">
                                            </path>
                                        </svg>
                                    </span>
                                    <div class="info-text">
                                        <span class="text-secondary">Phone</span>
                                        <p class="text-primary">+91 9633 274 214</p>
                                    </div>
                                </div>
                                <div class="info-item dextheme-animation" data-animate="animate__slideInLeft">
                                    <span class="info-icon">
                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-envelope"
                                            viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z">
                                            </path>
                                        </svg>
                                    </span>
                                    <div class="info-text">
                                        <span class="text-secondary">E-mail</span>
                                        <p class="text-primary">info@aaravamshc.com</p>
                                    </div>
                                </div>
                                <div class="info-item dextheme-animation" data-animate="animate__slideInLeft">
                                    <span class="info-icon">
                                        <svg aria-hidden="true" class="e-font-icon-svg e-fas-map-marker-alt"
                                            viewBox="0 0 384 512" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z">
                                            </path>
                                        </svg>
                                    </span>
                                    <div class="info-text">
                                        <span class="text-secondary">Address</span>
                                        <p class="text-primary">
                                            Ground Floor, Valiyara Arcade,<br>
                                            UC College P.O,<br>
                                            Near UC College,<br>
                                            Aluva, Kerala 683102
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- FORM COLUMN -->
                    <div class="dextheme-col-lg-6 dextheme-col-md-12 mob">
                        <div class="consultation-form bg-secondary-opaque dextheme-animation"
                            data-animate="animate__slideInDown">
                            <div class="heading-text">
                                <h4>Book your Consultation.</h4>
                                <p>Let our specialists guide you to the perfect hearing or speech solution.</p>
                            </div>

                            <!-- Form (ids added for JS) -->
                            <form id="consultForm" class="dextheme-row gy-4 mb-4" onsubmit="return false;">
                                <div class="dextheme-col-lg-12 dextheme-col-md-12">
                                    <input id="ch_name" type="text" placeholder="Your Name" />
                                </div>
                                <div class="dextheme-col-lg-6 dextheme-col-md-12">
                                    <input id="ch_email" type="email" placeholder="Your Email" />
                                </div>
                                <div class="dextheme-col-lg-6 dextheme-col-md-12">
                                    <input id="ch_phone" type="text" placeholder="Phone Number" />
                                </div>

                                <div class="dextheme-col-md-12">
                                    <textarea id="ch_message" rows="5"
                                        placeholder="Tell us your concern here..."></textarea>
                                </div>
                            </form>

                            <!-- button wired to JS -->
                            <button id="submitWhatsApp" class="dextheme-btn btn-secondary hover-primary no-effect"
                                type="button">
                                Submit Request
                            </button>
                        </div>
                    </div>

                    <!-- IMAGE COLUMN -->
                    
                </div>
            </div>

            <!-- ===== WhatsApp script (paste once per page) ===== -->
            <script>
                (function () {
                    // ====== CONFIG: put your clinic WhatsApp number here (country code + number, digits only) ======
                    const whatsappNumber = "919633274214"; // example: for +91 9633 274 214 -> "91" + "9633274214"

                    function isMobile() {
                        return /Android|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i.test(navigator.userAgent);
                    }

                    function sanitizeInput(str) {
                        return (str || "").trim();
                    }

                    document.getElementById("submitWhatsApp").addEventListener("click", function () {
                        const name = sanitizeInput(document.getElementById("ch_name").value);
                        const email = sanitizeInput(document.getElementById("ch_email").value);
                        const phone = sanitizeInput(document.getElementById("ch_phone").value);
                        const message = sanitizeInput(document.getElementById("ch_message").value);

                        // Minimal validation: require name and phone or email
                        if (!name) {
                            alert("Please enter your name.");
                            return;
                        }
                        if (!phone && !email) {
                            alert("Please provide a phone number or email so we can contact you.");
                            return;
                        }

                        // Compose WhatsApp message
                        let text = "New Consultation Request%0A";
                        text += "*Name:* " + encodeURIComponent(name) + "%0A";
                        if (phone) text += "*Phone:* " + encodeURIComponent(phone) + "%0A";
                        if (email) text += "*Email:* " + encodeURIComponent(email) + "%0A";
                        if (message) text += "*Concern:* " + encodeURIComponent(message) + "%0A";
                        // Optionally include page URL and timestamp
                        text += "%0A" + encodeURIComponent("Source: Website");

                        // Choose link for mobile / desktop
                        const encodedText = text; // already url encoded parts
                        let url = "";
                        if (isMobile()) {
                            // mobile: use whatsapp scheme which opens the app
                            url = "whatsapp://send?phone=" + whatsappNumber + "&text=" + encodedText;
                        } else {
                            // desktop: open WhatsApp Web
                            url = "https://web.whatsapp.com/send?phone=" + whatsappNumber + "&text=" + encodedText;
                        }

                        // Open new tab / window
                        window.open(url, "_blank");

                        // optional: clear form after sending
                        // document.getElementById("consultForm").reset();
                    });
                })();
            </script>
        </section>

    </main>
    <?php include 'footer.php'; ?>
    <script type="text/javascript" src="assets/vendor/js/lightbox-plus-jquery.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/progressbar.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/swiper-bundle.min.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const currentPath = window.location.pathname;

            // Ambil semua link dari navbar
            const allLinks = document.querySelectorAll(
                ".navbar-nav a.nav-link, .navbar-nav a.dropdown-item"
            );

            allLinks.forEach((link) => {
                const href = link.getAttribute("href");

                // Abaikan jika href kosong atau #
                if (!href || href === "#") return;

                // Buat URL absolut dari href
                const linkUrl = new URL(href % 2c % 20window.location.html);

                // Jika cocok dengan path sekarang
                if (linkUrl.pathname === currentPath) {
                    // Tambah active ke link yang cocok
                    link.classList.add("active");

                    // Jika ini dropdown-item, tambahkan active ke parent nav-link-nya
                    const parentDropdown = link.closest(".dropdown");
                    if (parentDropdown) {
                        const parentLink = parentDropdown.querySelector(".nav-link");
                        if (parentLink) {
                            parentLink.classList.add("active");
                        }
                    }
                }
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

    <!-- Appointment Modal -->
    <div class="modal fade" id="appointmentModal" tabindex="-1" aria-labelledby="appointmentModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="appointmentModalLabel">Book an Appointment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="whatsappForm" novalidate>
                        <div class="mb-3">
                            <label for="userName" class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="userName" required>
                            <div class="invalid-feedback">Please enter your name.</div>
                        </div>
                        <div class="mb-3">
                            <label for="userPhone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="userPhone" required pattern="[0-9]{10}">
                            <div class="invalid-feedback">Enter a valid 10-digit phone number.</div>
                        </div>
                        <div class="mb-3">
                            <label for="serviceSelect" class="form-label">Desired Service</label>
                            <select class="form-select" id="serviceSelect" required>
                                <option selected value="">Select a Service</option>
                                <option value="Audiology">Audiology</option>
                                <option value="Speech Therapy">Speech Therapy</option>
                                <option value="Products">Products Enquiry</option>
                                <option value="General Enquiry">General Enquiry</option>
                            </select>
                            <div class="invalid-feedback">Please select a service.</div>
                        </div>
                        <div class="text-center mt-4">
                            <button type="submit" class="dextheme-btn w-100">Send Details</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast-container" class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="toastMessage" class="toast align-items-center text-bg-success border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body" id="toastText">
                    Details sent successfully!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
            </div>
        </div>
    </div>

    <!-- Script -->
    <script>
        const form = document.getElementById('whatsappForm');
        const nameInput = document.getElementById('userName');
        const phoneInput = document.getElementById('userPhone');
        const serviceSelect = document.getElementById('serviceSelect');
        const toastEl = document.getElementById('toastMessage');
        const toastText = document.getElementById('toastText');

        // Bootstrap toast setup
        const toast = new bootstrap.Toast(toastEl, { delay: 3000 });

        // Real-time validation
        form.querySelectorAll('input, select').forEach(field => {
            field.addEventListener('input', () => {
                if (field.checkValidity()) {
                    field.classList.remove('is-invalid');
                    field.classList.add('is-valid');
                } else {
                    field.classList.remove('is-valid');
                    field.classList.add('is-invalid');
                }
            });
        });

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            if (!form.checkValidity()) {
                form.classList.add('was-validated');
                toastText.textContent = "Please fill all required fields correctly.";
                toastEl.classList.remove('text-bg-success');
                toastEl.classList.add('text-bg-danger');
                toast.show();
                return;
            }

            const name = nameInput.value.trim();
            const phone = phoneInput.value.trim();
            const service = serviceSelect.value.trim();
            const recipientNumber = '919633274214';

            const message = `*New Appointment Request (via Website Modal)*%0A%0A` +
                `Name: ${name}%0A` +
                `Phone: ${phone}%0A` +
                `Service: ${service}%0A%0A` +
                `Please help me book an appointment.`;

            try {
                const whatsappUrl = `https://wa.me/${recipientNumber}?text=${message}`;
                window.open(whatsappUrl, '_blank');

                // Success toast
                toastText.textContent = "Details sent successfully!";
                toastEl.classList.remove('text-bg-danger');
                toastEl.classList.add('text-bg-success');
                toast.show();

                // Hide modal & reset form
                const modalElement = document.getElementById('appointmentModal');
                const modalInstance = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
                modalInstance.hide();

                form.reset();
                form.querySelectorAll('.is-valid').forEach(el => el.classList.remove('is-valid'));
            } catch (error) {
                toastText.textContent = "Message not sent. Please try again.";
                toastEl.classList.remove('text-bg-success');
                toastEl.classList.add('text-bg-danger');
                toast.show();
            }
        });
    </script>

</body>

<!-- Mirrored from psikolog-html-preview.dextheme.net/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 08 Oct 2025 04:08:23 GMT -->

</html>