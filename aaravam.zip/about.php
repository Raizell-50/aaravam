<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Aaravam</title>

    <link rel="icon" type="image/x-icon" href="assets/images/logo/title-icon.png" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="assets/css/main.min.css" />
    <link rel="stylesheet" href="assets/css/custom.html" />
    <link rel="stylesheet" href="assets/vendor/css/ekiticons3b71.css" />
    <link rel="stylesheet" href="assets/vendor/css/animate.min.css" />
    <link rel="stylesheet" href="assets/vendor/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/vendor/css/lightbox.min.css" />
    <script type="text/javascript" src="assets/vendor/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap"
        rel="stylesheet">
</head>

<style>
    .core-advantages {

        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 30px;
        padding-top: 70px;
        padding-bottom: 80px;
        background-color: #e3f7ff;
    }


    .features-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 30px;
        max-width: 1300px;
        width: 90%;
    }


    .feature-card {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        background: #ffffff;
        padding: 40px 30px;
        border-radius: 20px;
        border: 1px solid #cbcbcb;
        transition: all 0.3s ease;
    }

    .feature-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .feature-card .icon {
        font-size: 60px;
        color: #62c7ff;
        margin-bottom: 20px;

    }

    .feature-card .content h3 {
        font-size: 20px;
        color: #002244;
        margin-bottom: 10px;
        font-weight: 700;
    }

    .feature-card .content p {
        font-size: 15px;
        color: #555;
        line-height: 1.6;
        margin: 0;
    }


    @media (max-width: 992px) {
        .features-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
    }

    @media (max-width: 600px) {
        .features-grid {
            grid-template-columns: 1fr;
            width: 85%;
        }

        .core-advantages {
            padding-top: 50px;
            padding-bottom: 50px;
        }
    }
</style>


<body>
    <?php include 'header.php'; ?>

    <div class="backdrop" id="drawerBackdrop"></div>
    <main class="bg-white">
        <section class="heading-wrapper">
            <div class="dextheme-container">
                <div class="title-breadcrumb">
                    <h2>About Us</h2>
                    <div class="breadcrumb-wrapper">
                        <p><a href="index.php">Home</a> - About Us</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="dextheme-section-padding bg-white">
            <div class="dextheme-container">
                <div class="dextheme-row about-me-split-card">
                    <div class="dextheme-col-lg-6 dextehme-col-12">
                        <div class="profile-image">
                            <img src="assets/images/aaravam/aaravam.jpg">

                        </div>
                    </div>
                    <div class="dextheme-col-lg-6 dextehme-col-12 d-lg-flex flex-column justify-content-center">
                        <div class="heading-section mb-3">
                            <h1 class="heading-title mb-4 m-pt">Expert Speech and<br> Hearing Solutions</h1>
                            <h5 class="heading-subtitle" style="line-height: 21px; color: black;">Modern hearing aids, accurate
                                evaluations, and speech therapy to enhance communication.</h5>
                            <p style="line-height: 24px; color: black;">
                                At Aaravam Speech and Hearing Aid Centre, we believe that hearing well and speaking well
                                leads to living better. Located at near UC College Aluva, our clinic is dedicated to
                                providing comprehensive hearing and speech solutions for people of all age groups.We
                                offer a wide range of hearing care and speech therapy services, combining advanced
                                technology with compassionate care. Our team ensures that every individual receives
                                personalized assessment, expert guidance, and the right treatment to improve
                                communication and quality of life.
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <section class="core-advantages">
            <h2 class="text-primary text-center mb-4">Professional & Trustworthy</h2>

            <div class="features-grid">

                <div class="feature-card">
                    <div class="icon"><i class="fa-solid fa-headphones"></i></div>
                    <div class="content">
                        <h3>Acoustic Chamber</h3>
                        <p>Our chamber features advanced soundproofing, ensuring a pristine, ultra-quiet environment.
                            This is crucial for highly accurate hearing assessments and a comfortable patient
                            consultation.</p>
                    </div>
                </div>

                <div class="feature-card">
                    <div class="icon"><i class="fa-solid fa-stethoscope"></i></div>
                    <div class="content">
                        <h3>Certified Pathologists</h3>
                        <p>Our team of certified Audiologists and Speech-Language Pathologists combines professional
                            expertise with compassionate care to deliver precise, personalized, and effective therapy
                            for every individual.</p>
                    </div>
                </div>

                <div class="feature-card">
                    <div class="icon"><i class="fa-solid fa-hand-holding-heart"></i></div>
                    <div class="content">
                        <h3>Customer Satisfaction</h3>
                        <p>From first consultation to ongoing support, we prioritize every patient’s comfort and
                            confidence — a commitment reflected in the lasting trust and appreciation of those we serve.
                        </p>
                    </div>
                </div>

                <div class="feature-card">
                    <div class="icon"><i class="fa-solid fa-heart"></i></div>
                    <div class="content">
                        <h3>Personalized Care for Every Voice and Ear</h3>
                        <p>We treat every patient as unique, developing customized treatment plans that precisely match
                            individual needs, preferences, and lifestyle for the most effective outcome.</p>
                    </div>
                </div>

            </div>
        </section>





        <section class="dextheme-section-padding bg-white">
            <div class="dextheme-container">
                <div class="dextheme-row gx-5">
                    <div class="dextheme-col-lg-4 dextehme-col-12">
                        <div class="profile-image">
                            <img src="assets/images/aaravam/babitha-paul.jpg">
                        </div>
                    </div>
                    <div class="dextheme-col-lg-4 dextehme-col-12 d-lg-flex flex-column justify-content-center">
                        <div class="heading-section mb-3 pb-2">
                            <h1 class="heading-title mb-1 m-pt">Babitha Paul</h1>
                            <p style="font-weight: 600; font-size: 17px;">Audiologist & Speech Language Pathologist</p>
                        </div>
                        <div class="professional-background">
                            <div class="">
                                <h4 class="text-primary mt-2 mb-0">Certified as an Audiologist and Speech Pathologist
                                </h4>
                                <p class="text-secondary">by Rehabilation Council of India</p>
                            </div>
                            <div class="">
                                <h4 class="text-primary mt-2 mb-0">15+ years of experience in Audiology and Speech
                                    Therapy </h4>

                            </div>

                        </div>
                    </div>
                    <div class="dextheme-col-lg-4 dextehme-col-12 d-lg-flex flex-column justify-content-center">
                        <h3 class="text-primary mb-2">Philosophy:</h3>
                        <p class="text-primary mb-4">With over 15 years of dedicated experience in audiology and speech
                            therapy, Babitha has served as Lead Audiologist at Medical Trust Hospital, Cochin. Her
                            compassionate approach and clinical expertise have helped countless individuals rediscover
                            the joy of clear hearing and confident communication.</p>
                        <div class="specialization">
                            <h4 class="text-primary mb-3">Specializations:</h4>
                            <ul class="specialization-lists">
                                <li class="list-item">
                                    <span class="bg-secondary svg-icon circle-check-icon"></span>
                                    Pediatric audiology
                                </li>
                                <li class="list-item">
                                    <span class="bg-secondary svg-icon circle-check-icon"></span>
                                    Geriatric audiology
                                </li>
                                <li class="list-item">
                                    <span class="bg-secondary svg-icon circle-check-icon"></span>
                                    Rehabilitative audiology
                                </li>
                                <li class="list-item">
                                    <span class="bg-secondary svg-icon circle-check-icon"></span>
                                    Pediatric speech pathology
                                </li>
                                <li class="list-item">
                                    <span class="bg-secondary svg-icon circle-check-icon"></span>
                                    Fluency disorders
                                </li>
                            </ul>
                        </div>
                    </div>


                </div>
            </div>
        </section>

    </main>
    <?php include 'footer.php'; ?>
    <script type="text/javascript" src="assets/vendor/js/lightbox-plus-jquery.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/progressbar.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/swiper-bundle.min.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const currentPath = window.location.pathname;

            // Ambil semua link dari navbar
            const allLinks = document.querySelectorAll('.navbar-nav a.nav-link, .navbar-nav a.dropdown-item');

            allLinks.forEach(link => {
                const href = link.getAttribute('href');

                // Abaikan jika href kosong atau #
                if (!href || href === '#') return;

                // Buat URL absolut dari href
                const linkUrl = new URL(href % 2c % 20window.location.html);

                // Jika cocok dengan path sekarang
                if (linkUrl.pathname === currentPath) {
                    // Tambah active ke link yang cocok
                    link.classList.add('active');

                    // Jika ini dropdown-item, tambahkan active ke parent nav-link-nya
                    const parentDropdown = link.closest('.dropdown');
                    if (parentDropdown) {
                        const parentLink = parentDropdown.querySelector('.nav-link');
                        if (parentLink) {
                            parentLink.classList.add('active');
                        }
                    }
                }
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

    <!-- Appointment Modal -->
    <div class="modal fade" id="appointmentModal" tabindex="-1" aria-labelledby="appointmentModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="appointmentModalLabel">Book an Appointment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="whatsappForm" novalidate>
                        <div class="mb-3">
                            <label for="userName" class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="userName" required>
                            <div class="invalid-feedback">Please enter your name.</div>
                        </div>
                        <div class="mb-3">
                            <label for="userPhone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="userPhone" required pattern="[0-9]{10}">
                            <div class="invalid-feedback">Enter a valid 10-digit phone number.</div>
                        </div>
                        <div class="mb-3">
                            <label for="serviceSelect" class="form-label">Desired Service</label>
                            <select class="form-select" id="serviceSelect" required>
                                <option selected value="">Select a Service</option>
                                <option value="Audiology">Audiology</option>
                                <option value="Speech Therapy">Speech Therapy</option>
                                <option value="Products">Products Enquiry</option>
                                <option value="General Enquiry">General Enquiry</option>
                            </select>
                            <div class="invalid-feedback">Please select a service.</div>
                        </div>
                        <div class="text-center mt-4">
                            <button type="submit" class="dextheme-btn w-100">Send Details</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast-container" class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="toastMessage" class="toast align-items-center text-bg-success border-0" role="alert"
            aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body" id="toastText">
                    Details sent successfully!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
            </div>
        </div>
    </div>

    <!-- Script -->
    <script>
        const form = document.getElementById('whatsappForm');
        const nameInput = document.getElementById('userName');
        const phoneInput = document.getElementById('userPhone');
        const serviceSelect = document.getElementById('serviceSelect');
        const toastEl = document.getElementById('toastMessage');
        const toastText = document.getElementById('toastText');

        // Bootstrap toast setup
        const toast = new bootstrap.Toast(toastEl, { delay: 3000 });

        // Real-time validation
        form.querySelectorAll('input, select').forEach(field => {
            field.addEventListener('input', () => {
                if (field.checkValidity()) {
                    field.classList.remove('is-invalid');
                    field.classList.add('is-valid');
                } else {
                    field.classList.remove('is-valid');
                    field.classList.add('is-invalid');
                }
            });
        });

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            if (!form.checkValidity()) {
                form.classList.add('was-validated');
                toastText.textContent = "Please fill all required fields correctly.";
                toastEl.classList.remove('text-bg-success');
                toastEl.classList.add('text-bg-danger');
                toast.show();
                return;
            }

            const name = nameInput.value.trim();
            const phone = phoneInput.value.trim();
            const service = serviceSelect.value.trim();
            const recipientNumber = '919633274214';

            const message = `*New Appointment Request (via Website Modal)*%0A%0A` +
                `Name: ${name}%0A` +
                `Phone: ${phone}%0A` +
                `Service: ${service}%0A%0A` +
                `Please help me book an appointment.`;

            try {
                const whatsappUrl = `https://wa.me/${recipientNumber}?text=${message}`;
                window.open(whatsappUrl, '_blank');

                // Success toast
                toastText.textContent = "Details sent successfully!";
                toastEl.classList.remove('text-bg-danger');
                toastEl.classList.add('text-bg-success');
                toast.show();

                // Hide modal & reset form
                const modalElement = document.getElementById('appointmentModal');
                const modalInstance = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
                modalInstance.hide();

                form.reset();
                form.querySelectorAll('.is-valid').forEach(el => el.classList.remove('is-valid'));
            } catch (error) {
                toastText.textContent = "Message not sent. Please try again.";
                toastEl.classList.remove('text-bg-success');
                toastEl.classList.add('text-bg-danger');
                toast.show();
            }
        });
    </script>

</body>


</html>