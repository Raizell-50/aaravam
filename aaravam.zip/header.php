<!-- Navbar Section -->
<nav class="navbar navbar-expand-lg navbar-white bg-white">
  <div class="dextheme-container">
    <div class="dextheme-navbar d-flex w-100 fd">
      <div class="logo-brand my-auto">
        <a href="index.php">
          <img src="assets/images/logo/logo.png" />
        </a>
      </div>
      <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse mob-none" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link" href="index.php"> HOME </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php"> ABOUT US </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="audiology.php"> AUDIOLOGY </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="speech-therapy.php"> SPEECH THERAPY </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="product.php"> PRODUCTS </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">CONTACT</a>
          </li>
        </ul>

        <button class="dextheme-btn btn-primary hover-normal-black no-effect mob-none" data-bs-toggle="modal"
          data-bs-target="#appointmentModal" type="button" style="background: #fff; color: #2d82d8; border: 3px solid #2d82d8;">
          Book Appointment
        </button>
      </div>
    </div>
  </div>
</nav>



<!-- Mobile Navbar Section -->
<div class="dextheme-menu-drawer" id="mobileMenu">
  <button class="drawer-close" id="closeDrawer">&times;</button>
  <div class="drawer-inner">
    <div class="drawer-logo">
      <img src="assets/images/logo/logo.png" alt="Logo">
    </div>
    <ul class="mobile-nav-list">
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="audiology.php">Audiology</a></li>
      <li><a href="speech-therapy.php">Speech Therapy</a></li>
      <li><a href="product.php">Products</a></li>
      <li><a href="contact.php">Contact</a></li>
    </ul>
  </div>
</div>
<div class="dextheme-drawer-overlay" id="drawerOverlay"></div>


<script>
  const menuBtn = document.getElementById('menuBtn');
  const closeDrawer = document.getElementById('closeDrawer');
  const drawer = document.getElementById('mobileMenu');
  const overlay = document.getElementById('drawerOverlay');

  menuBtn?.addEventListener('click', () => {
    drawer.classList.add('active');
    overlay.classList.add('active');
  });

  closeDrawer?.addEventListener('click', () => {
    drawer.classList.remove('active');
    overlay.classList.remove('active');
  });

  overlay?.addEventListener('click', () => {
    drawer.classList.remove('active');
    overlay.classList.remove('active');
  });
</script>
