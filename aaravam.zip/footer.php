<!-- <footer class="psikolog-footer">
  <div class="footer-top">
    <div class="container footer-grid">
      
      <div class="col logo-col">
        <a href="index.php">
        <img src="assets/images/logo/logo2.png" alt="Psikolog logo" class="footer-logo" />
      </a>
        <p class="footer-desc">
          Aaravam is your family's partner for complete speech therapy and audiology services in a supportive, welcoming
          environment.
        </p>
      </div>

      
      <div class="col links-col">
        <h4 class="col-heading">Quick Links</h4>
        <ul class="footer-menu">
          <li><a href="index.php">Home</a></li>
          <li><a href="#">About Us</a></li>
          <li><a href="#">Audiology</a></li>
          <li><a href="#">Speech Therapy</a></li>
          <li><a href="#">Products</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>

      
      <div class="col services-col">
        <h4 class="col-heading">Social Platforms</h4>
        <div class="services-two">
          <ul class="footer-menu">
            <li><a href="#">facebook</a></li>
            <li><a href="#">Instagram</a></li>
            <li><a href="#">Twitter</a></li>
          </ul>
        </div>
      </div>

      
      <div class="col contact-col">
        <h4 class="col-heading">Contact Us</h4>
        <ul class="contact-list">
          <li class="contact-item">
            
            <svg class="ci" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z" />
            </svg>
            <span>Ground Floor, Valiyara Arcade,<br>
              UC College P.O,<br>
              Near UC College,<br>
              Aluva, Kerala 683102</span>
          </li>
          <li class="contact-item">
            <svg class="ci" viewBox="0 0 24 24">
              <path
                d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4l-8 5L4 8V6l8 5 8-5v2z" />
            </svg>
            <a href="mailto:info@aaravamshc.com">info@aaravamshc.com</a>
          </li>
          <li class="contact-item">
            <svg class="ci" viewBox="0 0 24 24">
              <path
                d="M6.62 10.79a15.46 15.46 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.01-.24c1.12.37 2.33.57 3.58.57a1 1 0 0 1 1 1v3.5a1 1 0 0 1-1 1A19 19 0 0 1 3 5a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.46.57 3.58a1 1 0 0 1-.24 1.01l-2.2 2.2z" />
            </svg>
            <a href="tel:919633274214">+91 9633 274 214</a>
          </li>
        </ul>
      </div>
    </div>

   
  </div>

    
    <div class="footer-bottom">
      <div class="container bottom-inner">
        

        <div class="bottom-center">
          <p class="copyright" style="margin-top: 8px; margin-bottom: 8px !important;">Aaravam, 2025 © All Rights Reserved</p>
        </div>
      </div>
    </div>
</footer> -->

<footer class="psikolog-footer">
  <div class="footer-top">
    <div class="container footer-grid">
      <div class="col logo-col">
        <a href="index.php">
          <img src="assets/images/logo/logo2.png" alt="Psikolog logo" class="footer-logo" />
        </a>
      </div>

      <div class="col links-col">
        <h4 class="col-heading">QUICK LINKS</h4>
        <ul class="footer-menu">
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="product.php">Products</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>

      <div class="col services-menu-col">
        <h4 class="col-heading">SERVICES</h4>
        <ul class="footer-menu">
          <li><a href="audiology.php">Audiology</a></li>
          <li><a href="speech-therapy.php">Speech Therapy</a></li>
        </ul>
      </div>
      <div class="col social-col"> <h4 class="col-heading">SOCIAL</h4>
        <ul class="footer-menu">
          <li><a href="#">Facebook</a></li>
          <li><a href="#">Instagram</a></li>
          <li><a href="#">Twitter</a></li>
        </ul>
      </div>

      <div class="col contact-col">
        <h4 class="col-heading">CONTACT US</h4>
        <ul class="contact-list">
          <li class="contact-item">
            <svg class="ci" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z" />
            </svg>
            <span>Ground Floor, Valiyara Arcade,<br>
              UC College P.O,<br>
              Near UC College,<br>
              Aluva, Kerala 683102</span>
          </li>
          <li class="contact-item">
            <svg class="ci" viewBox="0 0 24 24">
              <path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4l-8 5L4 8V6l8 5 8-5v2z" />
            </svg>
            <a href="mailto:info@aaravamshc.com">info@aaravamshc.com</a>
          </li>
          <li class="contact-item">
            <svg class="ci" viewBox="0 0 24 24">
              <path
                d="M6.62 10.79a15.46 15.46 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.01-.24c1.12.37 2.33.57 3.58.57a1 1 0 0 1 1 1v3.5a1 1 0 0 1-1 1A19 19 0 0 1 3 5a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.46.57 3.58a1 1 0 0 1-.24 1.01l-2.2 2.2z" />
            </svg>
            <a href="tel:919633274214">+91 9633 274 214</a>
          </li>
        </ul>
      </div>
    </div>
  </div>

  <div class="footer-bottom">
    <div class="container bottom-inner">
      <div class="bottom-center">
        <p class="copyright" style="margin-bottom: 0px;">Aaravam Speech and Hearing Aid centre, 2025 © All Rights Reserved</p>
      </div>
    </div>
  </div>
</footer>



<!-- Floating WhatsApp Button -->
<a href="https://wa.me/919633274214" class="whatsapp-float" target="_blank" aria-label="Chat on WhatsApp" style="text-decoration: none">
    <i class="fab fa-whatsapp"></i>
</a>


<!-- Mobile Footer Buttons -->
<div class="mobile-footer">
  <a href="https://wa.me/919633274214" target="_blank" style="padding-right: 10px;">
    <i class="fab fa-whatsapp"></i>
    
  </a>
  <a href="tel:+919633274214">
    <i class="fas fa-phone"></i>
    
  </a>
  <a href="https://maps.app.goo.gl/ZE8C8gAiPgvNwXSy6" target="_blank" style="padding-left: 10px;">
    <i class="fas fa-map-marker-alt"></i>
    
  </a>
</div>