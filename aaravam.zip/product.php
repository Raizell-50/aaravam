<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Aaravam - Pricing</title>

    <link rel="icon" type="image/x-icon" href="assets/images/logo/title-icon.png" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="assets/css/main.min.css" />
    <link rel="stylesheet" href="assets/css/custom.html" />
    <link rel="stylesheet" href="assets/vendor/css/ekiticons3b71.css" />
    <link rel="stylesheet" href="assets/vendor/css/animate.min.css" />
    <link rel="stylesheet" href="assets/vendor/css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="assets/vendor/css/lightbox.min.css" />
    <script type="text/javascript" src="assets/vendor/js/bootstrap.js"></script>
    <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200..800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400..900&display=swap" rel="stylesheet">
</head>

<style>
    /* Custom CSS for Product Cards and Toggle Functionality */
    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    /* Section Styling */
    .hearing-aids-section {
        padding: 60px 0;
        text-align: center;
    }

    .section-title {
        font-size: 46px;
        color: #333;
        margin-bottom: 10px;
    }

    .section-subtitle {
        font-size: 1.2em;
        color: #666;
        margin-bottom: 40px;
    }

    /* Product Grid (3-column layout) */
    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        justify-content: center;
        align-items: start;
    }

    /* Product Card */
    .product-card {
        border: 1px solid #ddd;
        background-color: #fff;
        border-radius: 10px;

        padding: 30px;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: left;
        transition: box-shadow 0.3s ease, transform 0.3s ease;
        overflow: hidden;
        align-self: start;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    }

    .product-image-wrapper {
        width: 150px;
        height: 150px;
        margin-bottom: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }

    .product-image {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
    }

    .product-title {
        font-size: 1.4em;
        color: #333;
        margin-bottom: 10px;
        font-weight: bold;
        width: 100%;
    }

    /* Smooth Transition Toggle - ADJUSTED FOR SMOOTHNESS */
    .product-description-container {
        overflow: hidden;
        max-height: 100px;
        /* Initial max-height */
        /* === SMOOTHNESS KEY 1: Increased duration for a gentler animation === */
        transition: max-height 2s ease-in-out;
        width: 100%;
        padding-bottom: 20px;
    }

    .product-description-container p {
        margin: 0 0 10px 0;
        font-size: 0.9em;
        color: #777;
        line-height: 1.6;
    }

    .product-description-container .expandable-text {
        margin-top: 10px;
        border-top: 1px solid #f0f0f0;
        padding-top: 10px;
    }

    /* === SMOOTHNESS KEY 2: Very large max-height when expanded === */
    .product-card.expanded .product-description-container {
        max-height: 1500px;
    }

    /* Read More Button */
    .read-more-btn {
        background-color: #20b2e6;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        transition: background-color 0.3s ease;
        margin-top: auto;
    }

    .read-more-btn:hover {
        background-color: #20b2e6;
    }

    .arrow {
        
       
        display: inline-block;
        
    }

    .down {
        
        transition: transform 0.3s ease;
    }

    .product-card.expanded .read-more-btn .down {
        transform: rotate(180deg);
    }

    @media (max-width: 768px) {
        .section-title {
            font-size: 2em;
        }

        .product-grid {
            grid-template-columns: 1fr;
        }
    }


    /* Hearing Aid accessories */

    .hearing-aid-accessories {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
        font-family: 'Urbanist', sans-serif;
    }

    .hearing-aid-accessories h1 {
        text-align: center;
        margin-bottom: 40px;
        font-size: 46px;
        color: #333;
    }

    /* Accessory Item Styling (Flex Container) */
    .accessory-item {
        display: flex;
        align-items: stretch;
        margin-bottom: 40px;
        gap: 30px;
        border: 1px solid #eee;

        padding: 20px;
        background-color: #fff;
    }

    /* Image Container Styling */
    .accessory-image-container {
        flex: 1;
        min-width: 45%;
        overflow: hidden;
    }

    .accessory-image-container img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    /* Text Details Styling */
    .accessory-details {
        flex: 1;
        padding: 10px 0;
    }

    .accessory-details h2 {
        font-size: 1.8em;
        margin-top: 0;
        margin-bottom: 10px;
        color: #16485c;

        padding: 10px;
        display: inline-block;
    }

    /* --- Key for Alternating Layout --- */
    .accessory-item.reversed {
        flex-direction: row-reverse;
    }

    /* Responsive Adjustments for Smaller Screens (Optional but Recommended) */
    @media (max-width: 768px) {
        .accessory-item {
            flex-direction: column;
            gap: 15px;
        }


        .accessory-item.reversed {
            flex-direction: column;
        }

        .accessory-image-container,
        .accessory-details {
            min-width: 100%;
        }

        .hearing-aid-accessories h1 {
            font-size: 2em;
        }
    }
</style>

<body>
    <?php include("header.php"); ?>

    <div class="backdrop" id="drawerBackdrop"></div>
    <main class="bg-white">
        <section class="heading-wrapper">
            <div class="dextheme-container">
                <div class="title-breadcrumb">
                    <h2>Products</h2>
                    <div class="breadcrumb-wrapper">
                        <p><a href="index.php">Home</a> - Products</p>
                    </div>
                </div>
            </div>
        </section>


        <section class="hearing-aids-section">
            <div class="container">
                <h2 class="section-title">Hearing Aids</h2>
                <p class="section-subtitle">Types of Hearing Aids and Their Features</p>

                <div class="product-grid">

                    <div class="product-card" id="card-receiver-in-canal-ric">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/ric1.jpg" alt="Receiver in Canal RIC Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Receiver in Canal (RIC)</h3>

                        <div class="product-description-container" id="content-receiver-in-canal-ric">
                            <p>RIC aids are popular because the device is small and discreetly placed behind the ear,
                                with a thin wire running to a speaker inside the ear canal.</p>
                            <p class="expandable-text">They are ideal for mild to severe hearing loss, offering a
                                natural sound experience and excellent feature capacity, often including Bluetooth
                                streaming and rechargeable options.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-receiver-in-canal-ric">
                           <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                    <div class="product-card" id="card-rechargeable-ric">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/ric2.jpg" alt="Rechargeable RIC Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Rechargeable RIC</h3>

                        <div class="product-description-container" id="content-rechargeable-ric">
                            <p>This type of RIC hearing aid features a powerful, built-in battery that can be
                                conveniently charged overnight, eliminating the hassle of buying and changing disposable
                                batteries.</p>
                            <p class="expandable-text">They are designed for ease of use, providing a full day of power,
                                often including streaming time. They are suitable for various degrees of hearing loss
                                while maintaining a discreet profile.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-rechargeable-ric">
                            <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                    <div class="product-card" id="card-receiver-in-canal-ric-2">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/signia-ric.jpg" alt="Receiver in Canal RIC Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Receiver in Canal (RIC)</h3>

                        <div class="product-description-container" id="content-receiver-in-canal-ric-2">
                            <p>RIC hearing aids are an open-fit style where a miniature receiver (speaker) rests
                                comfortably inside the ear canal, connected by a nearly invisible thin wire to the main
                                unit.</p>
                            <p class="expandable-text">This design minimizes the "plugged up" feeling (occlusion) and is
                                effective for mild to profound hearing loss. They are known for superior sound quality
                                and advanced features like direct phone connection.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-receiver-in-canal-ric-2">
                            <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                    <div class="product-card" id="card-battery-operated-ric">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/signia-ric2.jpg" alt="Battery Operated RIC Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Battery Operated RIC</h3>

                        <div class="product-description-container" id="content-battery-operated-ric">
                            <p>These RIC devices rely on traditional disposable hearing aid batteries, offering
                                reliable, long-lasting power without needing a charging station every night.</p>
                            <p class="expandable-text">They provide the same high-quality sound and comfort as their
                                rechargeable counterparts, using small zinc-air batteries.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-battery-operated-ric">
                           <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                    <div class="product-card" id="card-behind-the-ear-bte">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/phonak-bte.jpg" alt="Behind the Ear BTE Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Behind the Ear (BTE)</h3>

                        <div class="product-description-container" id="content-behind-the-ear-bte">
                            <p>BTE hearing aids are worn behind the outer ear and route amplified sound into the ear
                                canal via a custom-made earmold or a thin tube.</p>
                            <p class="expandable-text">Due to their larger size, they can accommodate bigger batteries
                                for longer life and more powerful components, making them suitable for moderate to
                                profound hearing loss. They are robust and easy to handle.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-behind-the-ear-bte">
                           <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                    <div class="product-card" id="card-battery-operated-bte">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/signia-bte.jpg" alt="Battery Operated BTE Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Battery Operated BTC</h3>

                        <div class="product-description-container" id="content-battery-operated-bte">
                            <p>The Slim Behind-the-Ear (BTE) hearing aid is a modern, sleek version of the BTE design,
                                focusing on aesthetics and comfort while maintaining strong amplification performance.
                            </p>
                            <p class="expandable-text">This style is visually less noticeable than traditional BTEs and
                                is often equipped with the latest features, including advanced noise reduction, app
                                control, and telecoil options for clearer hearing.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-battery-operated-bte">
                           <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                    <div class="product-card" id="card-rechargeable-bte">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/bte-2.jpg" alt="Rechargeable BTE Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Rechargeable BTE</h3>

                        <div class="product-description-container" id="content-rechargeable-bte">
                            <p>This is a full-featured BTE aid that offers the convenience of rechargeable power,
                                simplifying your routine by docking the hearing aids at night instead of replacing
                                batteries.</p>
                            <p class="expandable-text">Rechargeable BTEs handle various levels of hearing loss, provide
                                hours of reliable usage, and are perfect for users who value power, robust construction,
                                and the latest connectivity features.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-rechargeable-bte">
                           <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                    <div class="product-card" id="card-completely-in-canal-cic">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/cic-1.jpg" alt="Completely in the Canal CIC Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Completely in the Canal (CIC)</h3>

                        <div class="product-description-container" id="content-completely-in-canal-cic">
                            <p>CIC aids are custom-molded to fit entirely inside your ear canal, making them highly
                                discreet and nearly invisible when worn.</p>
                            <p class="expandable-text">They are best for mild to moderate hearing loss. Their deep
                                placement uses the natural ear shape to funnel sound, but their small size limits
                                battery life and the inclusion of manual controls or advanced wireless features.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-completely-in-canal-cic">
                            <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                    <div class="product-card" id="card-battery-operated-itc">
                        <div class="product-image-wrapper">
                            <img src="assets/images/product/itc.jpg" alt="Battery Operated ITC Hearing Aid"
                                class="product-image">
                        </div>
                        <h3 class="product-title">Battery Operated ITC</h3>

                        <div class="product-description-container" id="content-battery-operated-itc">
                            <p>The In-The-Canal (ITC) hearing aid is custom-made to fit the shape of your ear and rests
                                comfortably in the lower portion of the ear canal.</p>
                            <p class="expandable-text">Being battery-operated, it offers consistent performance and a
                                good balance of size and features. It is a good option for mild to moderately severe
                                hearing loss, providing easy accessibility and controls.</p>
                        </div>

                        <div class="read-more-btn" data-card="card-battery-operated-itc">
                           <img src="assets/images/icon/down-arrow.png" alt="Read More Arrow" class="arrow down" style="height: 30px; width: 30px;">
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="hearing-aid-accessories">
            <h1>Hearing Aid Accessories</h1>

            <article class="accessory-item">
                <div class="accessory-image-container">
                    <img src="assets/images/product/battery.jpg" alt="Person inserting a battery into a hearing aid">
                </div>
                <div class="accessory-details">
                    <h2>Batteries</h2>
                    <p>We supply a full range of power solutions to keep your hearing aids working their best. Choose
                        from our reliable, long-lasting zinc-air disposable batteries, offered in all standard,
                        color-coded sizes. We also feature the latest in rechargeable battery technology, providing
                        convenient, all-day power with simple overnight charging. We ensure you get the correct battery
                        type and size for any hearing aid model.</p>
                </div>
            </article>

            <article class="accessory-item reversed">
                <div class="accessory-image-container">
                    <img src="assets/images/product/wire.jpg" alt="A set of hearing aid cleaning tools on a desk">
                </div>
                <div class="accessory-details">
                    <h2>Code</h2>
                    <p>We offer replacement Receiver Wires (often called receiver codes or speakers) as essential
                        accessories for Receiver-in-Canal (RIC) hearing aids. These components are crucial for
                        transmitting processed sound from the hearing aid body to the speaker in the ear canal. Wires
                        are available in multiple lengths, power levels (standard, medium, or power), and are clearly
                        coded to match your device, ensuring you maintain the highest sound quality.</p>
                </div>
            </article>

            <article class="accessory-item">
                <div class="accessory-image-container">
                    <img src="assets/images/product/tips.jpg" alt="Person inserting a battery into a hearing aid">
                </div>
                <div class="accessory-details">
                    <h2>Tips</h2>
                    <p>The soft silicone tips—known as Domes—that attach to your receiver are vital for comfort and
                        performance. Available in S, M, L, and XL sizes, we offer various styles including Open Domes
                        for natural sound, Closed Domes for greater amplification, and Power Domes for a tight seal to
                        prevent whistling. Domes must be replaced regularly to maintain hygiene and optimal function.
                        We ensure you get the correct size and style for any hearing aid model.</p>
                </div>
            </article>

            <article class="accessory-item reversed">
                <div class="accessory-image-container">
                    <img src="assets/images/product/mould.jpg" alt="A set of hearing aid cleaning tools on a desk">
                </div>
                <div class="accessory-details">
                    <h2>Mould (Soft/Hard)</h2>
                    <p>We supply custom Hearing Aid Earmolds for various device styles, which provide a personalized and
                        superior fit. These molds come in two types: Soft Molds offer maximum comfort and a secure seal,
                        ideal for active users or those with severe hearing loss; while Hard Molds provide enhanced
                        durability and are easier to handle and clean. Both are custom-made from ear impressions to
                        ensure optimal sound quality and comfortable wear.</p>
                </div>
            </article>

            <article class="accessory-item">
                <div class="accessory-image-container">
                    <img src="assets/images/product/services.jpg" alt="Person inserting a battery into a hearing aid">
                </div>
                <div class="accessory-details">
                    <h2>Aid Sales and Services</h2>
                    <p>We offer a full range of services, starting with a consultation to help you choose the ideal
                        hearing aid based on your needs. This is followed by a precise fitting and programming to
                        optimize sound quality and comfort. Our comprehensive aftercare includes ongoing adjustments,
                        cleaning, maintenance, and routine checks to ensure your devices perform optimally for years to
                        come.</p>
                </div>
            </article>

            <article class="accessory-item reversed">
                <div class="accessory-image-container">
                    <img src="assets/images/product/other.jpg" alt="A set of hearing aid cleaning tools on a desk">
                </div>
                <div class="accessory-details">
                    <h2>Other Accessories</h2>
                    <p>Beyond domes and custom molds, we stock a full range of essential accessories to ensure the
                        longevity and enhanced performance of your hearing aids. This includes Wax Guards and Cleaning
                        Kits to maintain hygiene and prevent blockages, and Dehumidifiers/Drying Kits to protect against
                        moisture damage. For improved connectivity, we also offer Wireless Streamers and Remote
                        Microphones to provide clear audio from TVs and in noisy environments.</p>
                </div>
            </article>

        </section>



    </main>

    <?php include 'footer.php'; ?>

    <script type="text/javascript" src="assets/vendor/js/lightbox-plus-jquery.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/countUp.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/progressbar.min.js"></script>
    <script type="text/javascript" src="assets/vendor/js/swiper-bundle.min.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Highlight current menu
            const currentPath = window.location.pathname;
            const allLinks = document.querySelectorAll('.navbar-nav a.nav-link, .navbar-nav a.dropdown-item');
            allLinks.forEach(link => {
                const href = link.getAttribute('href');
                if (!href || href === '#') return;
                const linkUrl = new URL(href, window.location.href);
                if (linkUrl.pathname === currentPath) {
                    link.classList.add('active');
                    const parentDropdown = link.closest('.dropdown');
                    if (parentDropdown) {
                        const parentLink = parentDropdown.querySelector('.nav-link');
                        if (parentLink) parentLink.classList.add('active');
                    }
                }
            });

            // Toggle expansion per card
            document.querySelectorAll('.read-more-btn').forEach(button => {
                button.addEventListener('click', function () {
                    const cardId = this.getAttribute('data-card');
                    const card = document.getElementById(cardId);

                    // --- Single Expansion Logic (The core functionality) ---
                    if (card) {
                        // Toggles the clicked card's expansion state
                        card.classList.toggle('expanded');
                    }
                });
            });
        });
    </script>
</body>

</html>